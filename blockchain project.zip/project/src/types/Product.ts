export interface Product {
  id: string;
  name: string;
  manufacturer: string;
  origin: string;
  manufacturingDate: string;
  batchNumber: string;
  condition: 'Good' | 'Warning' | 'Critical';
  isNatural: boolean;
  temperature: number;
  humidity: number;
  lastScanned: string;
  blockchainId: string;
}

export interface ScanHistory {
  timestamp: string;
  location: string;
  temperature: number;
  humidity: number;
  condition: 'Good' | 'Warning' | 'Critical';
}