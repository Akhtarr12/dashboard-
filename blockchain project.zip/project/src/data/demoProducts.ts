import { Product } from '../types/Product';

export const demoProducts: Product[] = [
  {
    id: '1234',
    name: 'Organic Coffee Beans',
    manufacturer: 'Mountain View Coffee Co.',
    origin: 'Colombia',
    manufacturingDate: '2024-03-15',
    batchNumber: 'BATCH-2024-001',
    condition: 'Good',
    isNatural: true,
    temperature: 22,
    humidity: 45,
    lastScanned: '2024-03-20 14:30',
    blockchainId: '0x1234...5678'
  },
  {
    id: '1235',
    name: 'Organic Honey',
    manufacturer: 'Pure Bee Farms',
    origin: 'New Zealand',
    manufacturingDate: '2024-02-20',
    batchNumber: 'BATCH-2024-045',
    condition: 'Good',
    isNatural: true,
    temperature: 18,
    humidity: 35,
    lastScanned: '2024-03-19 09:15',
    blockchainId: '0x5678...9012'
  },
  {
    id: '1236',
    name: 'Extra Virgin Olive Oil',
    manufacturer: 'Mediterranean Oils',
    origin: 'Greece',
    manufacturingDate: '2024-01-10',
    batchNumber: 'BATCH-2024-112',
    condition: 'Warning',
    isNatural: true,
    temperature: 25,
    humidity: 55,
    lastScanned: '2024-03-18 16:45',
    blockchainId: '0x9012...3456'
  }
];