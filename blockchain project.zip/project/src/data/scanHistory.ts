import { ScanHistory } from '../types/Product';

export const scanHistory: Record<string, ScanHistory[]> = {
  '1234': [
    {
      timestamp: '2024-03-20 14:30',
      location: 'Distribution Center, Seattle',
      temperature: 22,
      humidity: 45,
      condition: 'Good'
    },
    {
      timestamp: '2024-03-18 09:15',
      location: 'Warehouse, Portland',
      temperature: 21,
      humidity: 44,
      condition: 'Good'
    },
    {
      timestamp: '2024-03-15 16:20',
      location: 'Manufacturing Plant, Colombia',
      temperature: 23,
      humidity: 46,
      condition: 'Good'
    }
  ],
  '1235': [
    {
      timestamp: '2024-03-19 09:15',
      location: 'Retail Store, Sydney',
      temperature: 18,
      humidity: 35,
      condition: 'Good'
    },
    {
      timestamp: '2024-03-17 11:30',
      location: 'Distribution Center, Auckland',
      temperature: 19,
      humidity: 38,
      condition: 'Good'
    }
  ],
  '1236': [
    {
      timestamp: '2024-03-18 16:45',
      location: 'Warehouse, Athens',
      temperature: 25,
      humidity: 55,
      condition: 'Warning'
    },
    {
      timestamp: '2024-03-15 14:20',
      location: 'Manufacturing Plant, Kalamata',
      temperature: 22,
      humidity: 50,
      condition: 'Good'
    }
  ]
};