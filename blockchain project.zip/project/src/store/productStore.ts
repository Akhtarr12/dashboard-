import { create } from 'zustand';
import { Product } from '../types/Product';
import { demoProducts } from '../data/demoProducts';

interface ProductState {
  currentProduct: Product | null;
  setCurrentProduct: (product: Product | null) => void;
  scanProduct: (id: string) => void;
}

export const useProductStore = create<ProductState>((set) => ({
  currentProduct: null,
  setCurrentProduct: (product) => set({ currentProduct: product }),
  scanProduct: (id) => {
    const product = demoProducts.find(p => p.id === id);
    if (product) {
      set({ currentProduct: product });
    }
  }
}));