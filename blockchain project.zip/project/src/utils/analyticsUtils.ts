import { Product, ScanHistory } from '../types/Product';

export const calculateAverageTemperature = (history: ScanHistory[]): number => {
  return Math.round(history.reduce((acc, scan) => acc + scan.temperature, 0) / history.length);
};

export const calculateAverageHumidity = (history: ScanHistory[]): number => {
  return Math.round(history.reduce((acc, scan) => acc + scan.humidity, 0) / history.length);
};

export const getConditionDistribution = (products: Product[]): Record<string, number> => {
  return products.reduce((acc, product) => {
    acc[product.condition] = (acc[product.condition] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
};