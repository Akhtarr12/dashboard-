import React from 'react';
import { Package2, ThermometerSun, Droplets, MapPin, Calendar, Factory } from 'lucide-react';
import { Product } from '../types/Product';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const conditionColors = {
    Good: 'bg-green-100 text-green-800',
    Warning: 'bg-yellow-100 text-yellow-800',
    Critical: 'bg-red-100 text-red-800',
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800">{product.name}</h2>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${conditionColors[product.condition]}`}>
          {product.condition}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center space-x-3">
          <Factory className="w-5 h-5 text-gray-600" />
          <div>
            <p className="text-sm text-gray-500">Manufacturer</p>
            <p className="font-medium">{product.manufacturer}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <MapPin className="w-5 h-5 text-gray-600" />
          <div>
            <p className="text-sm text-gray-500">Origin</p>
            <p className="font-medium">{product.origin}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Calendar className="w-5 h-5 text-gray-600" />
          <div>
            <p className="text-sm text-gray-500">Manufacturing Date</p>
            <p className="font-medium">{product.manufacturingDate}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Package2 className="w-5 h-5 text-gray-600" />
          <div>
            <p className="text-sm text-gray-500">Batch Number</p>
            <p className="font-medium">{product.batchNumber}</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <ThermometerSun className="w-5 h-5 text-gray-600" />
          <div>
            <p className="text-sm text-gray-500">Temperature</p>
            <p className="font-medium">{product.temperature}°C</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <Droplets className="w-5 h-5 text-gray-600" />
          <div>
            <p className="text-sm text-gray-500">Humidity</p>
            <p className="font-medium">{product.humidity}%</p>
          </div>
        </div>
      </div>

      <div className="mt-6 pt-6 border-t border-gray-200">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-500">Last Scanned</p>
            <p className="font-medium">{product.lastScanned}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">Blockchain ID</p>
            <p className="font-medium font-mono text-sm">{product.blockchainId}</p>
          </div>
        </div>
      </div>
    </div>
  );
};