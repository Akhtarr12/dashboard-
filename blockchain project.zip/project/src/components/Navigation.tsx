import React from 'react';
import { Scan, History, BarChart3 } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export const Navigation: React.FC = () => {
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path ? 'text-blue-600' : 'text-gray-600 hover:text-gray-900';
  };

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <Link to="/" className="flex items-center">
            <Scan className="w-8 h-8 text-blue-600" />
            <span className="ml-2 text-xl font-semibold">ProductChain</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link 
              to="/history" 
              className={`flex items-center space-x-2 ${isActive('/history')}`}
            >
              <History className="w-5 h-5" />
              <span>History</span>
            </Link>
            <Link 
              to="/analytics" 
              className={`flex items-center space-x-2 ${isActive('/analytics')}`}
            >
              <BarChart3 className="w-5 h-5" />
              <span>Analytics</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};