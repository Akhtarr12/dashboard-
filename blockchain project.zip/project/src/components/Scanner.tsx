import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Scan } from 'lucide-react';
import { useProductStore } from '../store/productStore';
import { demoProducts } from '../data/demoProducts';

export const Scanner: React.FC = () => {
  const [scanning, setScanning] = useState(false);
  const scanProduct = useProductStore(state => state.scanProduct);

  const handleScan = () => {
    setScanning(true);
    // Simulate scanning by randomly selecting a product
    setTimeout(() => {
      const randomProduct = demoProducts[Math.floor(Math.random() * demoProducts.length)];
      scanProduct(randomProduct.id);
      setScanning(false);
    }, 1500);
  };

  return (
    <div className="flex flex-col items-center space-y-6">
      <div className="relative">
        <div className={`w-64 h-64 border-2 ${scanning ? 'border-blue-500' : 'border-gray-300'} rounded-lg`}>
          <QRCodeSVG
            value="demo-product-1234"
            size={256}
            level="H"
            className="p-2"
          />
          {scanning && (
            <div className="absolute inset-0 bg-blue-500/10 animate-pulse rounded-lg" />
          )}
        </div>
      </div>

      <button
        onClick={handleScan}
        disabled={scanning}
        className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-colors ${
          scanning 
            ? 'bg-gray-400 cursor-not-allowed' 
            : 'bg-blue-600 hover:bg-blue-700 text-white'
        }`}
      >
        <Scan className="w-5 h-5" />
        <span>{scanning ? 'Scanning...' : 'Scan Product'}</span>
      </button>
    </div>
  );
};