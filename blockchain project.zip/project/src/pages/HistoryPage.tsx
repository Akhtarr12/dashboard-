import React, { useState } from 'react';
import { HistoryTable } from '../components/HistoryTable';
import { ProductCard } from '../components/ProductCard';
import { scanHistory } from '../data/scanHistory';
import { demoProducts } from '../data/demoProducts';

export const HistoryPage: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState(demoProducts[0]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Product History</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">Products</h3>
            <div className="space-y-2">
              {demoProducts.map(product => (
                <button
                  key={product.id}
                  onClick={() => setSelectedProduct(product)}
                  className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                    selectedProduct.id === product.id
                      ? 'bg-blue-50 text-blue-700'
                      : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="font-medium">{product.name}</div>
                  <div className="text-sm text-gray-500">{product.batchNumber}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <ProductCard product={selectedProduct} />
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-4">Scan History</h3>
            <HistoryTable history={scanHistory[selectedProduct.id]} />
          </div>
        </div>
      </div>
    </div>
  );
};