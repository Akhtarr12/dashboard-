import React from 'react';
import { Scanner } from '../components/Scanner';
import { ProductCard } from '../components/ProductCard';
import { useProductStore } from '../store/productStore';

export const HomePage: React.FC = () => {
  const currentProduct = useProductStore(state => state.currentProduct);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="flex flex-col items-center space-y-8">
          <h2 className="text-2xl font-bold text-gray-900">Scan Product</h2>
          <Scanner />
        </div>
        
        <div className="space-y-8">
          <h2 className="text-2xl font-bold text-gray-900">Product Information</h2>
          {currentProduct ? (
            <ProductCard product={currentProduct} />
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6 text-center text-gray-500">
              Scan a product to view its information
            </div>
          )}
        </div>
      </div>
    </div>
  );
};