import React from 'react';
import { AnalyticsCard } from '../components/AnalyticsCard';
import { demoProducts } from '../data/demoProducts';
import { scanHistory } from '../data/scanHistory';
import { ThermometerSun, Droplets, Package2, AlertTriangle } from 'lucide-react';
import { 
  calculateAverageTemperature,
  calculateAverageHumidity,
  getConditionDistribution 
} from '../utils/analyticsUtils';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';

const COLORS = ['#22c55e', '#eab308', '#ef4444'];

export const AnalyticsPage: React.FC = () => {
  const allScans = Object.values(scanHistory).flat();
  const avgTemp = calculateAverageTemperature(allScans);
  const avgHumidity = calculateAverageHumidity(allScans);
  const conditions = getConditionDistribution(demoProducts);

  const pieData = Object.entries(conditions).map(([name, value]) => ({
    name,
    value
  }));

  const temperatureData = Object.entries(scanHistory).map(([id, scans]) => {
    const product = demoProducts.find(p => p.id === id);
    return {
      name: product?.name || id,
      temperature: scans[0].temperature,
      humidity: scans[0].humidity
    };
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Analytics Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <AnalyticsCard
          title="Average Temperature"
          value={`${avgTemp}°C`}
          icon={<ThermometerSun className="w-6 h-6" />}
          trend="stable"
          change="0%"
        />
        <AnalyticsCard
          title="Average Humidity"
          value={`${avgHumidity}%`}
          icon={<Droplets className="w-6 h-6" />}
          trend="up"
          change="+2%"
        />
        <AnalyticsCard
          title="Total Products"
          value={demoProducts.length}
          icon={<Package2 className="w-6 h-6" />}
        />
        <AnalyticsCard
          title="Products at Risk"
          value={conditions.Warning || 0}
          icon={<AlertTriangle className="w-6 h-6" />}
          trend="down"
          change="-1"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Product Conditions</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Environmental Conditions</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={temperatureData}>
                <XAxis dataKey="name" />
                <YAxis yAxisId="left" orientation="left" stroke="#22c55e" />
                <YAxis yAxisId="right" orientation="right" stroke="#3b82f6" />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left" dataKey="temperature" name="Temperature (°C)" fill="#22c55e" />
                <Bar yAxisId="right" dataKey="humidity" name="Humidity (%)" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};